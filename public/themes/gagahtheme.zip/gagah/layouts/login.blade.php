{{ Theme::partial('header')}}
<div class="main">
	<div class="container">
		{{ Theme::place('content')}}
	</div>
</div>
{{ Theme::partial('footer') }}