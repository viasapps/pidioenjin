{{ Theme::partial('header')}} 
<div class="main">
	<div class="container">
    	<div class="left"> 
            {{ Theme::place('content')}}
            <div class="social">
             	<div class="g-plusone" data-size="medium"></div>
                <!-- Place this tag after the last +1 button tag. -->
                <script type="text/javascript">
                    (function() {
                        var po = document.createElement('script'); po.type = 'text/javascript'; po.async = true;
                        po.src = 'https://apis.google.com/js/plusone.js';
                        var s = document.getElementsByTagName('script')[0]; s.parentNode.insertBefore(po, s);
                    })();
                </script>
             	<div class="fb-like" data-send="false" data-layout="button_count" data-width="150" data-show-faces="false" data-font="arial"></div>
             	<a href="https://twitter.com/share" class="twitter-share-button" data-hashtags="vectorea">Tweet</a>
                    <script>!function(d,s,id){var js,fjs=d.getElementsByTagName(s)[0],p=/^http:/.test(d.location)?'http':'https';if(!d.getElementById(id)){js=d.createElement(s);js.id=id;js.src=p+'://platform.twitter.com/widgets.js';fjs.parentNode.insertBefore(js,fjs);}}(document, 'script', 'twitter-wjs');</script>
             	<a rel="nofollow" href="//pinterest.com/pin/create/button/" data-pin-do="buttonBookmark" ><img src="//assets.pinterest.com/images/pidgets/pin_it_button.png" /></a>
                    <script type="text/javascript" src="//assets.pinterest.com/js/pinit.js"></script> 
             </div> 
            <div class="maintitles">
                <h3 id="description" class="selected">Description</h3>
                <h3 id="download">Download Video</h3>
            </div>
            <div class="widget"> 
            	<div class="ads728"></div><br />
            	<div id="description" class="single">
                @if(Route::currentRouteName() == 'video')
                    {{ spp($video->title) }}
                @endif
                </div>
                <div id="download"  class="single" style="display:none;">
                <ul class="download">
                    <li>{{ add_icon('download', link_to_route('download', 'MP4', array('id' => $video->id, 'format' => 'mp4', 'slug' => $video->slug), array('class' => 'iframe lightbox'))) }}</li>
                    <li>{{ add_icon('download', link_to_route('download', 'FLV', array('id' => $video->id, 'format' => 'flv', 'slug' => $video->slug), array('class' => 'iframe lightbox'))) }}</li>
                    <li>{{ add_icon('download', link_to_route('download', '3GP', array('id' => $video->id, 'format' => '3gp', 'slug' => $video->slug), array('class' => 'iframe lightbox'))) }}</li>
                    <li>{{ add_icon('download', link_to_route('download', 'MP3', array('id' => $video->id, 'format' => 'mp3', 'slug' => $video->slug), array('class' => 'iframe lightbox'))) }}</li>
                </ul>
                </div>
        	</div>
        	<div style="clear:both"></div>
		</div>
        <div class="right"> 
            <div class="box-titles">
                <h3>RELATED <span>VIDEOS</span></h3>
            </div> 
            <div class="related">
                {{ Theme::partial('related', array('videos' => $related_videos))}}
            </div>
        </div>
        <div style="clear:both"></div> 
</div>
{{ Theme::partial('footer') }}

