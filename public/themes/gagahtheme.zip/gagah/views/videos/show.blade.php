<div class="box-content-widget box-video-play span9">
    <div class="widget">
        <div class="widget-content">
            <div class="video-play">
                <iframe width="100%" height="500" src="http://www.youtube.com/embed/{{ $video->youtubeid }}?rel=0&amp;vq=hd720" frameborder="0" allowfullscreen></iframe>
            </div>
        </div>
    </div>
    <div class="main-titles">
        <h3>{{ $video->title}}</h3>
    </div>
</div> 
