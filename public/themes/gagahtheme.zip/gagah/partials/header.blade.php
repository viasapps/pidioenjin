<!DOCTYPE html>
<html lang="en" class="js js">
  <head>
    <meta http-equiv="Content-Type" content="text/html; charset=UTF-8">
    <meta charset="utf-8">
    <title>{{ Theme::place('title') }}</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta name="description" content="{{ Theme::place('meta_desc') }}">
    <meta name="keywords" content="{{ Theme::place('meta_keywords') }}">
	<link rel="stylesheet" type="text/css" href="{{ Theme::asset()->url('css/style.css') }}"> 
	<script src="{{ Theme::asset()->url('js/jquery.js') }}"></script> 
    <!-- Le HTML5 shim, for IE6-8 support of HTML5 elements -->
    <!--[if lt IE 9]>
      <script src="http://html5shim.googlecode.com/svn/trunk/html5.js">
      </script>
    <![endif]-->
    <!-- Le fav  -->
    <link rel="shortcut icon" href="{{ Theme::asset()->url('img/favicon.ico') }}">
  </head>
  <!-- activate scrollspy -->
  <body id="top" data-spy="scroll" data-target=".navbar" data-offset="50">
<div id="fb-root"></div>
<script>(function(d, s, id) {
  var js, fjs = d.getElementsByTagName(s)[0];
  if (d.getElementById(id)) return;
  js = d.createElement(s); js.id = id;
  js.src = "//connect.facebook.net/en_US/all.js#xfbml=1";
  fjs.parentNode.insertBefore(js, fjs);
}(document, 'script', 'facebook-jssdk'));
</script> 
    <!-- Nav button -->
    <a id="toggle" class="closed" aria-hidden="true">
      <i class="icon-reorder"></i>
    </a>
<!-- Navigation -->
<?php $cats = Config::get('videoengine.categories');?>
<div class="topmenu">
	<div class="head">
	<div class="logo">
        <h1><a href="{{ url('/') }}">Gagah <span>Video</span></a></h1>
        <!--<div class="desc">Download Latest Music Videos and More</div>-->
    </div>
    <div class="toogle"></div>
    <div class="menu">
    <ul>
        <li class="@if($active ==  'home') active @endif">{{ link_to('/', 'Home') }}</li>
        <li class="@if($active ==  'popular') active @endif">{{ link_to('popular', 'Popular') }}</li>
        <li class="@if($active ==  'newest') active @endif">{{ link_to('newest', 'New') }}</li>
        <li class="@if($active ==  'random') active @endif">{{ link_to('random', 'Random') }}</li>
        <li><a href="#">Categories &raquo;</a>
            <ul> 
                @foreach($cats as $cat)
                    <li>{{ add_icon('list', link_to_route('category', mb_convert_case(str_replace('-', ' ', $cat), MB_CASE_TITLE, "UTF-8"), array('slug' => $cat))) }}</li>
                @endforeach  
            </ul>
        </li>
    </ul>
    </div>
    </div>
</div>
<div class="header">
        <div class="search">
            {{ Form::open(array('url' => url(''), 'class' => 'form-inline form-search border-rd4')) }}
                <input placeholder="Enter search term here" name="q" type="text" class="box-text" value="@if(isset($search)){{ $search }}@endif">
                <button type="submit" class="btn-search">SEARCH</button>
            {{ Form::close()}}
            <p style="margin-left:5px; display:none;" > Or try these terms: 
                @foreach($terms as $term)
                  {{ link_to_route('term', $term->term, array('slug' => $term->slug),array('style' => 'text-decoration: underline;')) }} 
                @endforeach
                </p>
        </div>
        <div class="terms">
            <p style="margin-left:5px" > <span>Popular: </span>  
            <?php $termx = Config::get('videoengine.terms.index');?>
            <?php print_r($termx);?>
            <?php 
                foreach($terms as $term):
                  $linkedterm[] = link_to_route('term', $term->term, array('slug' => $term->slug));
                endforeach;
                $recterms = implode(", ", $linkedterm);
                echo $recterms;
            ?>
            </p> 
        </div> 
        <div style="clear:both"></div>
</div>